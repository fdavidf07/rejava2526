package tema4;

public class ProfesorTitularDFG extends ProfesorDFG  {

	public ProfesorTitularDFG(String dniProfesor, String nombre, String apellidos, int paramEdad) {
		super(dniProfesor, nombre, apellidos, paramEdad);
	}

	
	
}
